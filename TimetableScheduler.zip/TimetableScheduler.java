import java.util.Scanner;

public class TimetableScheduler {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of subjects: ");
        int numSubjects = sc.nextInt();
        sc.nextLine(); 
        String[] subjects = new String[numSubjects];
        for (int i = 0; i < numSubjects; i++) {
            System.out.print("Enter subject " + (i + 1) + ": ");
            subjects[i] = sc.nextLine();
        }

        
        int days = 5; 
        int slots = 7; 

        
        String[][] timetable = new String[days][slots];

        scheduleClasses(sc, timetable, subjects);

        System.out.println("\nInitial Timetable:");
        printTimetable(timetable);
        editTimetable(sc, timetable);
        System.out.println("\nFinal Timetable:");
        printTimetable(timetable);

        sc.close();
    }


    private static void scheduleClasses(Scanner sc, String[][] timetable, String[] subjects) {
        for (String sub : subjects) {
            System.out.println("\nFor subject '" + sub + "':");

            // Check if a lab or tutorial is already scheduled for the same subject on any day
            boolean check = checkLaborTut(timetable, sub);

            // If a lab or tutorial is already scheduled, skip scheduling for that subject
            if (check) {
                System.out.println(
                        "Lab or Tutorial already scheduled for " + sub + ". Skipping scheduling for this subject.");
                continue;
            }

            System.out.println("Select the class type: ");
            System.out.println("1. Lecture");
            System.out.println("2. Lab");
            System.out.println("3. Tutorial");
            System.out.print("Enter the option (1-3): ");

           
            int choice = sc.nextInt();
            sc.nextLine(); 

            int slotsRequired;

            switch (choice) {
                case 2: // Lab
                    slotsRequired = 3;
                    break;
                case 3: // Tutorial
                    slotsRequired = 2;
                    break;
                default: // Lecture
                    slotsRequired = 1;
                    break;
            }
// class schedule
            boolean scheduled = false;
            for (int day = 0; day < timetable.length && !scheduled; day++) {
                for (int slot = 0; slot <= timetable[day].length - slotsRequired; slot++) {
                    if (isSlotAvailable(timetable, day, slot, slotsRequired)) {
                        
                        for (int i = 0; i < slotsRequired; i++) {
                            timetable[day][slot + i] = sub;
                        }
                        scheduled = true;
                        break;
                    }
                }
            }

            // If a suitable slot is not found, print a message
            if (!scheduled) {
                System.out.println("Unable to schedule " + sub + ". Please try again later.");
            }
        }
    }

    // code for Check if a lab or tutorial is already scheduled for the same subject on any day
    private static boolean checkLaborTut(String[][] timetable, String subject) {
        for (int day = 0; day < timetable.length; day++) {
            for (int slot = 0; slot < timetable[day].length; slot++) {
                if (timetable[day][slot] != null && timetable[day][slot].equals(subject)) {
                    return true;
                }
            }
        }
        return false;
    }
    

    private static void editTimetable(Scanner sc, String[][] timetable) {
        while (true) {
            System.out.println("\nEnter day and slot to edit (e.g., Mon 3), or 'exit' to finish:");
            String input = sc.nextLine();

            if (input.equalsIgnoreCase("exit")) {
                break;
            }

            String[] tokens = input.split(" ");
            if (tokens.length != 2) {
                System.out.println("Invalid input. Please enter day and slot separated by a space.");
                continue;
            }

            int day = getIndex(tokens[0]);
            int slot = Integer.parseInt(tokens[1]) - 1;

            if (day < 0 || day >= timetable.length || slot < 0 || slot >= timetable[day].length) {
                System.out.println("Invalid day or slot. Please enter valid values.");
                continue;
            }
        
            // Check if editing is allowed in between a lab or tutorial
            if (!isEditAllowed(timetable, day, slot)) {
                System.out.println("Error: Editing not allowed in between a lab or tutorial.");
                continue;
            }

            System.out.println("Enter the new subject or 'free' to clear the slot:");
            String newSubject = sc.nextLine().trim();

            // Check if a lecture, lab, or tutorial already exists for the same subject on that day
            if (isClassScheduled(timetable, day, newSubject)) {
                System.out.println("Error: Lecture, Lab, or Tutorial already scheduled for " + newSubject + " on "
                        + getDayName(day) + ".");
                continue;
            }

            timetable[day][slot] = (newSubject.equalsIgnoreCase("free")) ? null : newSubject;

            System.out.println("Updated Timetable:");
            printTimetable(timetable);
        }
    }
    // Check if editing is allowed in between a lab or tutorial (2 or 3 slots continuously)
private static boolean isEditAllowed(String[][] timetable, int day, int slot) {
    int count = 0;

    for (int i = 0; i < timetable[day].length; i++) {
        if (timetable[day][i] != null && timetable[day][i].length() > 1) {
            count++;
        } else {
            count = 0;
        }

        if (count >= 3 && i >= slot) {
            return false; 
        }
    }

    return true; 
}


    // Check if a lecture, lab, or tutorial already exists for the same subject on that day
    private static boolean isClassScheduled(String[][] timetable, int day, String subject) {
        for (int slot = 0; slot < timetable[day].length; slot++) {
            if (timetable[day][slot] != null && timetable[day][slot].equals(subject)) {
                return true;
            }
        }
        return false;
    }
    private static int getIndex(String dayName) {
        switch (dayName.toLowerCase()) {
            case "mon":
                return 0;
            case "tue":
                return 1;
            case "wed":
                return 2;
            case "thu":
                return 3;
            case "fri":
                return 4;
            default:
                return -1;
        }
    }
    private static String getDayName(int day) {
        String[] week = { "Mon", "Tue", "Wed", "Thu", "Fri" };
        return week[day];
    }
    private static boolean isSlotAvailable(String[][] timetable, int day, int slot, int slotsRequired) {
        for (int i = 0; i < slotsRequired; i++) {
            if (timetable[day][slot + i] != null) {
                return false; 
            }
        }
        return true; 
    }

    private static void printTimetable(String[][] timetable) {
        String[] week = { "Mon", "Tue", "Wed", "Thu", "Fri" };

        for (int day = 0; day < timetable.length; day++) {
            System.out.print(week[day] + ": ");
            for (int slot = 0; slot < timetable[day].length; slot++) {
                String classScheduled = (timetable[day][slot] != null) ? timetable[day][slot] : "Free";
                System.out.print(classScheduled + "\t\t\t");
            }
            System.out.println();
        }
    }
}
